# CACH CHAY
- cài node
- chạy npm install
- chạy npm start